1. Zapni ezfrags2.cmd
2. Užívej :)